// Konfigurasi API URL
const CONFIG = {
  API_URL: 'http://localhost:5000/api'
};
